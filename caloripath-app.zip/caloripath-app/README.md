# CaloriPath 🎯

Your personalized calorie tracking companion with diet plans and recipes.

## Local Development

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```
